Component Versions:
===================
1. Jetty Web Server 8.1.9
2. OpenRDF Sesame 2.6.9 (the WAR files are custom-made with Ontop configuration page)
3. Protege 4.2 (beta 284)

